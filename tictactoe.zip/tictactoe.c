#include <stdio.h>

char board[3][3]; // 3x3 Tic Tac Toe board

// Function to initialize the board
void initBoard() {
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            board[i][j] = ' ';
}

// Function to print the board
void printBoard() {
    printf("\n");
    for(int i=0;i<3;i++) {
        printf(" %c | %c | %c \n", board[i][0], board[i][1], board[i][2]);
        if(i<2) printf("---|---|---\n");
    }
    printf("\n");
}

// Function to check if a player has won
char checkWinner() {
    // Check rows
    for(int i=0;i<3;i++)
        if(board[i][0]==board[i][1] && board[i][1]==board[i][2] && board[i][0]!=' ')
            return board[i][0];

    // Check columns
    for(int i=0;i<3;i++)
        if(board[0][i]==board[1][i] && board[1][i]==board[2][i] && board[0][i]!=' ')
            return board[0][i];

    // Check diagonals
    if(board[0][0]==board[1][1] && board[1][1]==board[2][2] && board[0][0]!=' ')
        return board[0][0];
    if(board[0][2]==board[1][1] && board[1][1]==board[2][0] && board[0][2]!=' ')
        return board[0][2];

    return ' '; // No winner yet
}

// Function to check if the board is full (draw)
int isDraw() {
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            if(board[i][j]==' ')
                return 0;
    return 1;
}

int main() {
    int row, col;
    char player = 'X';
    char winner = ' ';

    initBoard();
    printf("Tic Tac Toe Game\n");
    printBoard();

    while(winner==' ' && !isDraw()) {
        printf("Player %c, enter row (0-2) and column (0-2): ", player);
        scanf("%d %d", &row, &col);

        if(row<0 || row>2 || col<0 || col>2 || board[row][col]!=' ') {
            printf("Invalid move! Try again.\n");
            continue;
        }

        board[row][col] = player;
        printBoard();

        winner = checkWinner();
        if(winner!=' ' || isDraw()) break;

        // Switch player
        player = (player=='X') ? 'O' : 'X';
    }

    if(winner != ' ')
        printf("Player %c wins!\n", winner);
    else
        printf("It's a draw!\n");

    return 0;
}
